package com.example.myapplication

import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import java.util.*
import kotlin.collections.ArrayList


class MainActivity : AppCompatActivity() {

    lateinit var vText: TextView
    var request: Disposable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var vList = findViewById<LinearLayout>(R.id.act1_list)
        vText = findViewById<TextView>(R.id.act1_text)
        vText.setTextColor(0xFFFF0000.toInt())
        vText.setOnClickListener {
            Log.e("tag", "НАЖАТА КНОПКА")
            val i = Intent(this, SecondActivity::class.java)
            i.putExtra("tag", vText.text)
            startActivityForResult(i, 0)

            val o=Observable.create<String> {
                //net

                it.onNext("fiyguyhij")
            }.flatMap { Observable.create<String>{} }.zipWith(Observable.create<String>{}.map { it.second+it.first()}
                .subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())

            o.subscribe({},{})

            }, {

                Log.e("test", "", it)

            })
        }
        Log.v("tag", "НАЖАТА КНОПКА")

    }

    fun showLinearLayout(feedList:ArrayList<FeedItem>) {

        val inflater=layoutInflater
        inflater.inflate(R.layout.list_item)

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onStart() {
        super.onStart()
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onStop() {
        super.onStop()
    }

    override fun onDestroy() {
        super.onDestroy()
    }

}

private fun LayoutInflater.inflate(listItem: Int) {
    TODO("Not yet implemented")
}

class AT(val act:MainActivity):AsyncTask<String, Int, String>(){
    override fun doInBackground(vararg params: String?): String {
        return "XXX"
        TODO("Not yet implemented")
    }

    override fun onPostExecute(result: String?) {
        super.onPostExecute(result)

    }
}

class Feed( val items:ArrayList<FeedItem>)

class FeedItem(
    val title:String,
    val link:String,
    val thumbnail:String,
    val description:String
)

class Adapter(val items: ArrayList<FeedItem>):BaseAdapter() {
    override fun getCount(): Int {
        return item.size

    }

    override fun getItem(p0: Int): Any {
        return items[position]
    }

    override fun getItemId(p0: Int): Long {
        return position.toLong()

    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {

    }

}


